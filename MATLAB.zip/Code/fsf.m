d=[3;7;3;4;7;9]
y = d-1
for p=1:P
 for i=1:N
    %u=u+abs(d(p,i)*log(y(p,i))+(1-d(p,i)*log(1-y(p,i)))); %logarithmic error
    u=u+(d(p,i)-y(p,i))^2;
 end
end
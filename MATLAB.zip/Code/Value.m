function [d]= Value(a)

%d=(1-a*a)*exp((-1/2)*a*a);
d=exp((-1/2)*a*a)*cos(5*a);
%d=cos(5*a);


u = -10*pi:pi/100:10*pi
f = sin(pi*(u-0.5))-sin(2*pi*(u-0.5))
f = f./(pi*(u-0.5))
plot(u,f)
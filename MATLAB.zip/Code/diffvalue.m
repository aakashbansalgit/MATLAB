function [d]= Value(a)

%d=(a*a-3)*a*exp((-1/2)*a*a);
d=-exp((-1/2)*a*a)*(a*cos(5*a)+5*sin(5*a));
%d=5*sin(5*a);
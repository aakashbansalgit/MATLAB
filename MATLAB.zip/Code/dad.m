char2 = ''
char2int = 2
while (char2int > 0)
    modulo = mod((char2int - 1),26)
    modulo
    char2 = append(string(char('A' + modulo)),char2);
    char2int = (char2int - modulo) / 26;
    char2int = floor(char2int)
end
char2
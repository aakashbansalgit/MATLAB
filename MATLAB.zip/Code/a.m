function a(f1,f2)
fid = fopen('feedfwd.xls', 'w');
if(f1==1)
%6399504290560659611917012
prompt = {'Enter The File Name','Enter Number of Hidden neurons','Enter Number of Epochs','Enter Learning Rate', 'Enter minimum error to be reached', };
dlg_title = 'Input For Wavelet Neural Networks';
num_lines = 1;
defaultans = {'a.xlsx','15','3000', '0.01','0.001'};
options.Resize='on';
options.WindowStyle='normal';
options.Interpreter='tex';
answer = inputdlg(prompt,dlg_title,[1 60],defaultans,options);


%------------Data Input---------%
[inputfile,h,epo,rate,minrate]=answer{:};
tmp = xlsread(inputfile,'Sheet1');
rows = tmp(1,1);
cols = tmp(2,1);
sample=rows;
%s=round((60/100)*sample)
s = 17;
inp=cols; 
h=str2double(h);
out=1;
p=xlsread(inputfile,'Sheet2');
t=xlsread(inputfile,'Sheet3');
P = transpose(p);
p=P;
%P=transpose(p);
T = transpose(t);

fid = fopen('feedfwd.xls', 'w');


%-------------Parameters----------------%

for i=1:inp 
    m(i)=max(P(i,:));
end
for i=1:inp
    n(i)=min(P(i,:));
end
for i=1:inp
    for j=1:h  
        a(i,j)=0.5*(m(i)+n(i));
    end
 end
for i=1:inp
    for j=1:h
        b(i,j)=0.5*(m(i)-n(i));
    end
end
%display(a);
%display(b);
w=rand(h,out);
bias =0;
epoch=1;
epo=str2double(epo);
error=1;
err=0.0001;
rate= str2double(rate);
minrate=str2double(minrate);
bias=0;
rate = 0.001;
w1=rand(inp,out);
w2=rand(h,out);
y=rand(s,out);
l=1;
for i=1:sample
     sow(i)=i;
end
while( epoch<=epo)
    l=1;
    %----------outpput calculation----------%
    for itr=1:s
       
        for i=1:out
            y(itr,i)=0;
        end
        temp1=0;
        temp2=0;
        for i=1:inp
            for k=1:h
                z(i,k,itr)=(P(i,itr)-a(i,k))/b(i,k);
            end
        end
       
        for j=1:h
            phi(j,itr)=1;
            for k=1:inp
                phi(j,itr)=phi(j,itr)*(Value(z(k,j,itr)));
            end
        end
        
                
        for i=1:out
            temp1=0;
            for j=1:h
                temp1=temp1+w2(j,i)*phi(j,itr);
            end
            T1(itr,i)=temp1;
            y(itr,i)=y(itr,i)+temp1;
        end
        for i=1:out
            temp2=0;
            for j=1:inp
                temp2=temp2+w1(j,i)*P(j,itr);
            end
            T2(itr,i)=temp2;
            y(itr,i)=y(itr,i)+temp2;
        end
        
    end
    %--------error calculation--------%
    for i=1:s
        y(i)=y(i)+bias;
        e(i)=-(y(i)-T(i));
        C(l)=y(i);
        D(l)=T(i);
        
        l=l+1;
    end
    bias=bias+rate*(sum(e)/s);
    display(y); 
     
    %-----------updating weights------------%
    for i=1:inp
        w1temp(i)=0;
        for j=1:s
            w1temp(i)=w1temp(i)+(e(j))*P(i,j);
        end
    end
    for i=1:h 
        w2temp(i)=0;
        for j=1:s
             w2temp(i)=w2temp(i)+(e(j))*phi(i,j);
        end
    end
                
    for i=1:inp
        for j=1:h
            atemp(i,j)=0;
            for k=1:s
                atemp(i,j)=atemp(i,j)+(e(k))*(phi(j,k)*w2(j)*diffvalue(z(i,j,k)))/(a(i,j)*Value(z(i,j,k))); 
               
                
            end
        end 
    end
   % display(atemp);
 %   display(atemp);
  %  display(btemp);1  
    for i=1:inp
        for j=1:h
            btemp(i,j)=0;
            for k=1:s
                btemp(i,j)=btemp(i,j)+(e(k))*(z(i,j,k))*(phi(j,k)*w2(j)*diffvalue(z(i,j,k)))/(a(i,j)*Value(z(i,j,k)));
                
            end
        end
    end
    %display(w1);
    %display(w2);
    for i=1:inp
        w1(i)=w1(i)+(rate*w1temp(i));
    end
    for i=1:h
        w2(i)=w2(i)-(rate*w2temp(i));
    end
    for i=1:inp
        for j=1:h
            a(i,j)=a(i,j)-rate*atemp(i,j);
        end
    end
    
    for i=1:inp
        for j=1:h
            b(i,j)=b(i,j)+rate*btemp(i,j);
        end
    end
   % display(w1);
   % display(w2);
   for g=1:s
       e(g)=e(g)*e(g)/(2*s);
   end
    error=sum(e);
    f(epoch)=epoch;
    fu(epoch)=error;
   
    epoch=epoch+1; 

end

%disp("---------------Training Error-----------------");
display(error);

%--------Plotting Graph---------%

figure (1);
axis([0,inf,0,4]);
plot(f,fu);

% axis([0,1,0,1]);
% scatter(D,C);
% hold on;
% I=[0.1, 0.5 ,1];
% O=[0.1,0.5,1];
% plot(I,O);

%disp(s);
%disp(sample)
s=s+1;
l=1;
for itr=s:sample
        for i=1:out
            y(itr,i)=0;
        end
        temp1=0;
        temp2=0;
        for i=1:inp
            for k=1:h
                z(i,k,itr)=(P(i,itr)-a(i,k))/b(i,k);
            end
        end
       
        for j=1:h
            phi(j,itr)=1;
            for k=1:inp
                phi(j,itr)=phi(j,itr)*(Value(z(k,j,itr)));
            end
        end
        
                 
        for i=1:out
            temp1=0;
            for j=1:h
                temp1=temp1+w2(j,i)*phi(j,itr);
            end
            T1(itr,i)=temp1;
            y(itr,i)=y(itr,i)+temp1;
        end
        for i=1:out
            temp2=0;
            for j=1:inp
                temp2=temp2+w1(j,i)*P(j,itr);
            end
             T2(itr,i)=temp2;
            y(itr,i)=y(itr,i)+temp2;
        end
        
        
end
    error=0;
    for i=s:sample
        e(i)=(y(i)-T(i))*(y(i)-T(i))/(2*sample);
        A(l)=T(i);
        B(l)=y(i);
        l=l+1;
        error=error+e(i);
    end
    
    y=abs(y);
    y_trn=y(1:s,:);
    T_trn=transpose(T(:,1:s));
   figure (2);
   postreg(y_trn,T_trn);
    y_tst=y(s:sample,:);
    T_tst=transpose(T(:,s:sample));
    figure(3)
   postreg(y_tst,T_tst);
    
   figure(7)
   
    %postreg(y_tst,T_tst);
    
%     figure (4);
%     plot(sow,T);
% 
% %     plot(B,A,'--go');
%     figure(5);
%     plot(sow,y);
    
%     display(y);
%     display(T);
%     figure(6);
%     plot(sow,T);
%     %display(e); 
%     %disp(B);
%     %disp(A);
   
    %disp("-------------Testing error-----------------");
    
    display(error);
%%-----------------------------------------------------------------------------------------
% writing all the network characteristics to the output file feedfwd.xls 
%%-----------------------------------------------------------------------------------------
fprintf(fid,'\n %s \n\n',' WAVELET NEURAL NETWORK ');
fprintf(fid,'%s \n ','Network Parameters');
fprintf(fid,'Number of inputs = %d\n',cols);
fprintf(fid,'%s \n ','Number of outputs = 1');
fprintf(fid,'Number of hidden neurons = %d\n ', h);
fprintf(fid,'The WAVELET function at the hidden layer - MORLET \n');
fprintf(fid,'\n %s \n','TRAINING PARAMETERS');
fprintf(fid,'Learning rate used - %e \n' ,rate);
fprintf(fid,'Maximum numbers of epochs allowed - %d \n', epo);
fprintf(fid,'Goal (error) to be achieved - %e \n' ,minrate);
% fprintf(fid,'\n %s \n','Inputs and Target outputs');
fprintf(fid,'Number of input datasets for training = %d',s);
fprintf(fid,'\n\n');
fprintf(fid,'\n %s \n',' Training_data = ');
for i= 1:s
    for j=1:cols
         fprintf(fid, '%0.4f \t',P(j,i));
    end
    fprintf(fid,'\n');
end
fprintf(fid,'\n\n');
fprintf(fid,'%s \n','The target outputs for training ');
fprintf(fid,'\n\n');
fprintf(fid,' T_trn = \n');
for i=1:s
    fprintf(fid,' %0.4f \n',T(i));
end
fprintf(fid,'\n\n');
fprintf(fid,'%s \n','The ouputs estimated for training data ');
fprintf(fid,'\n\n');
fprintf(fid,' T_trn_estimated = \n');
for i=1:s
    fprintf(fid,' %0.4f \n',y(i));
end
fprintf(fid,'\n\n');

fprintf(fid,'\n %s \n',' Testing_data = ');
for i=s:sample
    for j=1:cols
        fprintf(fid, '%0.4f \t',P(j,i));
    end
    fprintf(fid,'\n');
end
fprintf(fid,'\n\n');
fprintf(fid,'\n %s \n',' Simulation of the network with the testing data');
fprintf(fid,'\n\n');

fprintf(fid,' %s\n',' The outputs obtained from the network for the test data sets are ');
for i=s:sample
    fprintf(fid,' %0.4f \n',y(i));
end
fprintf(fid,'\n');
fprintf(fid,' Error = %d \n',error);
fprintf(fid,'\n');
fprintf(fid,'\n \n  %s \n ' ,' translation parameters obtained from the network ');
for i=1:inp
    for j=1:h  
        fprintf(fid, '%0.4f \t',a(i,j));
    end
    fprintf(fid,'\n');
end
fprintf(fid,'\n');
fprintf(fid,'\n \n  %s \n ' ,' dilation parameters obtained from the network ');

for i=1:inp
    for j=1:h
        fprintf(fid, '%0.4f \t',b(i,j));
    end
    fprintf(fid,'\n');
end
fprintf(fid,'\n \n  %s \n ' ,' Weights obtained from the network ');
fprintf(fid,' %s \n',' Weights of the the connection links between the input layer and the output layer');
fprintf(fid,'\n');
for i= 1:inp
    fprintf(fid, '%0.4f \t',w1(i));
end
fprintf(fid,'\n');
fprintf(fid,' %s \n',' Weights of the the connection links between the hidden layer and the output layer');
for i= 1:h
    fprintf(fid, '%0.4f \t',w2(i));
end
fprintf(fid,'\n');
end           
   %disp("----------------------------------------------------------------------------------------------");
   %----------------Artificial Neural Networks-------------%
if(f2==1)
    prompt = {'Enter The File Name','Enter Number of Hidden neurons','Enter Number of Epochs','Enter Learning Rate', 'Enter minimum error to be reached', };
    dlg_title = 'Input For Wavelet Neural Networks';
    num_lines = 1;
    defaultans = {'a.xlsx','10','100', '0.001','0.001'};
    options.Resize='on';
    options.WindowStyle='normal';
    options.Interpreter='tex';
    answer = inputdlg(prompt,dlg_title,[1 60],defaultans,options);
    [inputfile,h,epo,rate,minrate]=answer{:};
    tmp = xlsread(inputfile,'Sheet1');
    p=xlsread(inputfile,'Sheet2');
    t=xlsread(inputfile,'Sheet3');
    P = transpose(p);
    p=P;
    %P=transpose(p);
    T = transpose(t);
    
    rows = tmp(1,1);
    cols = tmp(2,1);
    sample=rows;
    %s=round((60/100)*sample);
    s = 17;
    %disp("RUNNING ANN");
    P_trn =P(:,1:s);
    T_trn=T(:,1:s);
    P_tst=P(:,s:sample);
       T_tst=T(:,s:sample);           
       n=str2double(h);
       activationfn1='logsig';
       activationfn2='logsig';
       tf='traingd';
       for i = 1:cols
           in(i,1)=0;
           in(i,2)=1;
       end
       ffnet1=newff( in ,[n,1],{ activationfn1 activationfn2},tf);
       ffnet1.trainParam.show = 1;
       ffnet1.trainParam.lr = str2double(rate);
       ffnet1.trainParam.epochs = str2double(epo);
       ffnet1.trainParam.goal = str2double(minrate);
       [ffnet1,tr1]=train(ffnet1,P_trn,T_trn);
%        figure (4);
%        plot(tr1.epoch,tr1.perf);
       
       T_trainnet = sim (ffnet1,P_trn);
%        hold on;
%        I=[0.1, 0.5 ,1];
%        O=[0.1,0.5,1];
%        plot(I,O);
       T_net1 =  sim(ffnet1,P_tst);
       
       for i=1:s
           e(i)=-(T_trainnet(i)-T_trn(i));
       end
       for g=1:s
           e(g)=e(g)*e(g)/(2*s);
       end
       error=sum(e);
       %disp("-----------Training error---------");
       %disp(error);
       error=0;
       for i=1:sample-s
            e(i)=(T_net1(i)-T_tst(i))*(T_net1(i)-T_tst(i))/(2*sample);
            error=error+e(i);
       end
       %disp("-----------Testing error---------");
       %disp(error);
        fprintf(fid,'\n %s \n\n',' ARTIFICIAL NEURAL NETWORK ');
        fprintf(fid,'%s \n ','Network Parameters');
        fprintf(fid,'Number of inputs = %d\n',cols);
        fprintf(fid,'%s \n ','Number of outputs = 1');
        fprintf(fid,'Number of hidden neurons = %d\n ', n);
        fprintf(fid,'The activatio function used - logsig \n');
        fprintf(fid,'\n %s \n','TRAINING PARAMETERS');
        fprintf(fid,'Learning rate used - %e \n' ,ffnet1.trainParam.lr);
        fprintf(fid,'Maximum numbers of epochs allowed - %d \n', ffnet1.trainParam.epochs);
        fprintf(fid,'Goal (error) to be achieved - %e \n' ,ffnet1.trainParam.goal);
        % fprintf(fid,'\n %s \n','Inputs and Target outputs');
        fprintf(fid,'Number of input datasets for training = %d',s);
        fprintf(fid,'\n\n');
        fprintf(fid,'\n %s \n',' Training_data = ');
        for i= 1:s
            for j=1:cols
                 fprintf(fid, '%0.4f \t',P(j,i));
            end
            fprintf(fid,'\n');
        end
        fprintf(fid,'\n\n');
        fprintf(fid,'%s \n','The target outputs for training ');
        fprintf(fid,'\n\n');
        fprintf(fid,' T_trn = \n');
        for i=1:s
            fprintf(fid,' %0.4f \n',T(1,i));
        end
        fprintf(fid,'\n\n');
        fprintf(fid,'%s \n','The ouputs estimated for training data ');
        fprintf(fid,'\n\n');
        fprintf(fid,' T_trn_estimated = \n');
        for i=1:s
            fprintf(fid,' %0.4f \n',T_trainnet(1,i));
        end
        fprintf(fid,'\n\n');

        fprintf(fid,'\n %s \n',' Testing_data = ');
       
        for i=s:sample
            for j=1:cols
                fprintf(fid, '%0.4f \t',P(j,i));
            end
            fprintf(fid,'\n');
        end
        fprintf(fid,'\n\n');
        fprintf(fid,'\n %s \n',' Simulation of the network with the testing data');
        fprintf(fid,'\n\n');

        fprintf(fid,' %s\n',' The outputs obtained from the network for the test data sets are ');
        for i=1:sample-s
            fprintf(fid,' %0.4f \n',T_net1(1,i));
        end
        fprintf(fid,'\n');
        fprintf(fid,' Error = %d \n',error);
        fprintf(fid,'\n');
        fprintf(fid,'\n \n  %s \n ' ,' Weights obtained from the network ');
        fprintf(fid,' %s \n',' Weights of the the connection links between the input layer and the output layer');
        fprintf(fid,'\n');
        w1 = ffnet1.IW{1,1};
        [t1,t2]=size(w1);
        for i = 1:t1
            for j=1:t2
               fprintf(fid, '%0.4f \t',w1(i,j));
            end
            fprintf(fid,'\n');
        end

        fprintf(fid,'\n %s \n',' Weights of the the connection links between the hidden layer and the output layer');
        w2=ffnet1.LW{2,1};
        [t1,t2]=size(w2);
        for i = 1:t2
            for j=1:t1
               fprintf(fid, '%0.4f \t',w2(j,i));
            end
            fprintf(fid,'\n');
        end
        fprintf(fid,'\n');
        %disp('ugfuyfuyyf');
        %disp(T_net1);
        %disp(T_tst);
        figure(5);
        postreg(T_trn,T_trainnet);
        
        figure(6);
        postreg(T_net1,T_tst);
        
        figure(7);
        postreg(T_trn,T_trainnet);
end



            
        
            
        
        
        
        
        
        
        
        
        
        
        
        
        
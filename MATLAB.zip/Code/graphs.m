x = [5,10,15,20,25];
y = [0.0041,0.0045,0.0041,0.0061,0.0045];
figure(1);
plot(x,y,'-o');
hold on;
y = [0.0103,0.0083,0.0079,0.0087,0.0093];
plot(x,y,'-x');  

hold on;
y = [0.0095,0.0047,0.0042,0.0013,0.0015];
plot(x,y,'-o');

hold on;
y= [0.0138,0.0119,0.0097,0.009,0.0111];
plot(x,y,'-x');
title('Hidden Neurons Vs Error');
xlabel('Hidden Neurons');
ylabel('Error');
legend('WNN Training Error','WNN Testing Error','ANN Training Errror','ANN Testing Error');

hold off;
figure(2);
x = [500,1000,2000,3000,4000];
y = [0.0116,0.0086,0.0081,0.0043,0.0045];

plot(x,y,'-o');
hold on;

y = [0.0124,0.0117,0.0091,0.008,0.0084];
plot(x,y,'-x');  

hold on;

y= [0.0065,0.0038,0.0018,0.0039,0.0018];
plot(x,y,'-o');

hold on;
y = [0.01,0.0098,0.0096,0.0081,0.012];
plot(x,y,'-x');
title('Epochs Vs Error');
xlabel('Epochs');
ylabel('Error');
legend('WNN Training Error','WNN Testing Error','ANN Training Errror','ANN Testing Error');
hold off;
x = [1,2,3,4];
y = [0.0023,0.007,0.0045,0.0041];

figure(3);

plot(x,y,'-o');
% set(gca,'xtick',[]);
hold on;

y = [0.0142,0.0092,0.0089,0.0077];
plot(x,y,'-x');  
set(gca,'xtick',[]);
hold on;

y = [0.007,0.0021,0.0043,0.004];
plot(x,y,'-o');
set(gca,'xtick',[]);
hold on;

y=[0.0132,0.0129,0.011,0.0137];
plot(x,y,'-x');  
set(gca,'xtick',[]);
hold on;

title('Training-Testing Data Vs Error');

%xlabel('Training-Testing Data');
ylabel('Error');
legend('WNN Training Error','WNN Testing Error','ANN Training Errror','ANN Testing Error');

hold off;













x = [5,10,15,20,25];
y = [0.9,0.9,0.91,0.86,0.86];
figure(4);
plot(x,y,'-o');
hold on;
y = [0.87,0.81,0.9,0.85,0.78];
plot(x,y,'-x');  

hold on;
y = [0.73,0.81,0.89,0.89,0.84];
plot(x,y,'-o');

hold on;
y= [0.13,0.45,0.76,0.75,0.6];
plot(x,y,'-x');
title('Hidden Neurons Vs R-square');
xlabel('Hidden Neurons');
ylabel('R-square');
legend('WNN Training R-square','WNN Testing R-square','ANN Training R-square','ANN Testing R-square');

hold off;


figure(5);
x = [500,1000,2000,3000,4000];
y = [0.73,0.79,0.82,0.92,0.9];

plot(x,y,'-o');
hold on;

y = [0.52,0.73,0.81,0.88,0.81];
plot(x,y,'-x');  

hold on;

y= [0.82,0.9,0.91,0.9,0.9];
plot(x,y,'-o');

hold on;
y = [0.49,0.66,0.741,0.74,0.48];
plot(x,y,'-x');
title('Epochs Vs R-square');
xlabel('Epochs');
ylabel('R-square');
legend('WNN Training R-square','WNN Testing R-square','ANN Training R-square','ANN Testing R-square');
hold off;


x = [1,2,3,4];
y = [0.9,0.9,0.91,0.91];

figure(6);
plot(x,y,'-o');
hold on;

y = [0.72,0.66,0.86,0.89];
plot(x,y,'-x');  

hold on;

y = [0.9,0.9,0.91,0.89];
plot(x,y,'-o');

hold on;

y=[0.66,0.66,0.61,0.66];
plot(x,y,'-x');  

hold on;
set(gca,'xtick',[]);
title('Training-Testing Data Vs R-square');
%xlabel('Training-Testing Data');
ylabel('R-square');
legend('WNN Training R-square','WNN Testing R-square','ANN Training R-square','ANN Testing R-square');

hold off;


